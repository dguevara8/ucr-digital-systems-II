`include "src/GLOBALS/globals.vh"

module codegroup_encoder (
    input [7:0] code_group_eigthbit,
	input  running_disparity,
    output reg [9:0] tenbit_code_group_tenbit
);
    always @(code_group_eigthbit) begin
		//rx  +
		if (running_disparity) begin
			case(code_group_eigthbit)
				// Tabla para traducir de 8 a 10 bits los datos
				`D22p7_8bits: tenbit_code_group_tenbit = `D22p7_10bits_pos;
				`D24p7_8bits: tenbit_code_group_tenbit = `D24p7_10bits_pos;
				`D25p7_8bits: tenbit_code_group_tenbit = `D25p7_10bits_pos;
				`D26p7_8bits: tenbit_code_group_tenbit = `D26p7_10bits_pos;
				`D31p7_8bits: tenbit_code_group_tenbit = `D31p7_10bits_pos;

			endcase
		//RX -
		end else begin
					case(code_group_eigthbit)
				// Tabla para traducir de 8 a 10 bits los datos
				`D22p7_8bits: tenbit_code_group_tenbit = `D22p7_10bits_neg;
				`D24p7_8bits: tenbit_code_group_tenbit = `D24p7_10bits_neg;
				`D25p7_8bits: tenbit_code_group_tenbit = `D25p7_10bits_neg;
				`D26p7_8bits: tenbit_code_group_tenbit = `D26p7_10bits_neg;
				`D31p7_8bits: tenbit_code_group_tenbit = `D31p7_10bits_neg;
			endcase
		end
	end

endmodule
