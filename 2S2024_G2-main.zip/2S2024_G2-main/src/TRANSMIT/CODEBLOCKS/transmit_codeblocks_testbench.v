`include "src/GLOBALS/globals.vh"
`include "src/TRANSMIT/CODEBLOCKS/transmit_codeblocks.v"
`include "src/TRANSMIT/CODEBLOCKS/transmit_codeblocks_tester.v"

module transmit_codeblocks_testbench ();

wire mr_main_reset;
wire GTX_CLK;
wire tx_disparity;
wire [3:0] TX_O_SET;           
wire [7:0] TXD;               
wire TX_EVEN;
wire TX_OSET_INDICATE;
wire PUDR;
wire [9:0] TX_CODE_GROUP;


transmit_codeblocks DUT_TX_CB (
	.mr_main_reset(mr_main_reset),
	.GTX_CLK(GTX_CLK),
	.tx_disparity(tx_disparity),
	.TX_O_SET(TX_O_SET),           
	.TXD(TXD),               
	.TX_EVEN(TX_EVEN),            
	.TX_OSET_INDICATE(TX_OSET_INDICATE),   
	.PUDR(PUDR),
	.TX_CODE_GROUP(TX_CODE_GROUP)
);


transmit_codeblocks_tester TEST_TX_CB (
	.mr_main_reset(mr_main_reset),
	.GTX_CLK(GTX_CLK),
	.tx_disparity(tx_disparity),
	.TX_O_SET(TX_O_SET),           
	.TXD(TXD),               
	.TX_EVEN(TX_EVEN),            
	.TX_OSET_INDICATE(TX_OSET_INDICATE),   
	.PUDR(PUDR),
	.TX_CODE_GROUP(TX_CODE_GROUP)
);

initial begin
	$dumpfile("src/TRANSMIT/CODEBLOCKS/transmit_codeblocks.vcd");
	$dumpvars();	
	
end

endmodule

