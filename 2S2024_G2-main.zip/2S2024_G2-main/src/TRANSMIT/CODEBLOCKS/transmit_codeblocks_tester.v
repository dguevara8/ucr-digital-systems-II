`include "src/GLOBALS/globals.vh"
module transmit_codeblocks_tester (
    output reg mr_main_reset,
    output reg GTX_CLK,
    output reg tx_disparity,
    output reg [3:0] TX_O_SET,           
    output reg [7:0] TXD,               
    input TX_EVEN,            
    input TX_OSET_INDICATE,   
    input PUDR,
    input [9:0] TX_CODE_GROUP
    );

    
always begin
   #2 GTX_CLK = !GTX_CLK;
end

initial begin
    GTX_CLK = 1;
    mr_main_reset = 0;
    TXD = `D24p7_8bits;
    TX_O_SET = `OS_I;
    tx_disparity = 0;
    #4

    mr_main_reset = 1;
    #40

    TX_O_SET = `OS_S;
    #4
    TX_O_SET = `OS_D;
    
    #8

    TX_O_SET = `OS_T;
    #4    
    TX_O_SET = `OS_R;
    #4    
    TX_O_SET = `OS_I;
	#10 $finish;
end


endmodule
