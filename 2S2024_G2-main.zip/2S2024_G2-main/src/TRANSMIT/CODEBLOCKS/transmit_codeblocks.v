`include "src/GLOBALS/globals.vh"
`include "src/TRANSMIT/CODEBLOCKS/codegroup_encoder.v"

module transmit_codeblocks (
    input mr_main_reset,
    input GTX_CLK,
    output wire tx_disparity,
    input [3:0] TX_O_SET, // Esta entrada me dice que tengo poner en la salida           
    input [7:0] TXD,      // Esta entrada contiene los datos que tengo que codificar
    output reg TX_EVEN,            
    output reg TX_OSET_INDICATE,   
    output reg PUDR,   
    output reg [9:0] TX_CODE_GROUP
    );

//Codificacion de estados
localparam GENERATE_CODE_GROUPS   = 3'b000;
localparam SPECIAL_GO             = 3'b001;
localparam DATA_GO                = 3'b010;
//localparam IDLE_DISPARITY_OK      = 3'b011;
localparam IDLE_I2B               = 3'b100;

//Registros
reg [2:0] state_cb, nxt_state_cb;
reg running_disparity, running_disparity_nxt;
assign tx_disparity = running_disparity;
reg prev_gtx_clk;
reg DATA_CHAR;
reg [9:0] special_char, special_char_nxt;
reg idle_toogle, idle_toogle_nxt;
//Wire
wire cg_timer_done;
wire [9:0] salida_codificada;
integer unos;
integer ceros;
integer dispari;

codegroup_encoder ENCODER(
    .code_group_eigthbit(TXD),
    .running_disparity(running_disparity),
    .tenbit_code_group_tenbit(salida_codificada)
);



//Cg timer es una senal de control que es true cuando expira el timer, sin embargo,
//el timer expira automaticamente en el flanco positio de GTX_CLK
assign cg_timer_done = !prev_gtx_clk && GTX_CLK;
//Logica secuencial
always @(posedge GTX_CLK) begin
    if (!mr_main_reset) begin
        TX_OSET_INDICATE <= 1;
        state_cb <= GENERATE_CODE_GROUPS;
        prev_gtx_clk <= 0;
        TX_EVEN      <= 0;
        special_char <= `K28p6_10bits;
        DATA_CHAR     <= 0;
        special_char  <= 0;
        idle_toogle   <= 1;
        running_disparity <= 4;
    end else begin
        state_cb <= nxt_state_cb;
        running_disparity <= running_disparity_nxt;
        special_char <= special_char_nxt;
        idle_toogle <= idle_toogle_nxt;
        TX_EVEN <= !TX_EVEN;
        prev_gtx_clk <= 0;

    end
end


//Logica combinacional
//OS =Output Set
always @(*) begin
    nxt_state_cb = state_cb;
    idle_toogle_nxt = idle_toogle;
    //Funcion de disparidad
    //Cuento los unos
    unos =  ( TX_CODE_GROUP[9] + TX_CODE_GROUP[8] +  TX_CODE_GROUP[7] + TX_CODE_GROUP[6] + TX_CODE_GROUP[5] + TX_CODE_GROUP[4] + TX_CODE_GROUP[3] + TX_CODE_GROUP[2] +   TX_CODE_GROUP[1] + TX_CODE_GROUP[0]);
    //Calculo los ceros
    ceros = 10 - unos;
    //Calculo la disparidad
    dispari = unos - ceros;
    //Defino mi siguiente disparidad
    running_disparity_nxt = dispari >=0 ;
    
    //TX_OSET_INDICATE = 0;
    PUDR = 0;
    case(state_cb)
        GENERATE_CODE_GROUPS: begin
            //TX_OSET_INDICATE = 1;
            case(TX_O_SET)

                `OS_D: begin
                    TX_CODE_GROUP = salida_codificada;
                    TX_OSET_INDICATE = 1;
                    PUDR = 1;
                    idle_toogle_nxt = 1;

                end 
                    //nxt_state_cb = DATA_GO;
                `OS_I: begin //I
                    TX_CODE_GROUP = idle_toogle ? `K28p5_10bits: `D16p2_10bits;
                    idle_toogle_nxt = !idle_toogle;
                    //if (tx_disparity) nxt_state_cb = IDLE_DISPARITY_OK;
                end 
                `OS_V, //V
                `OS_S, //S
                `OS_T, //T
                `OS_R: begin //R
                    DATA_CHAR = 0;
                    TX_OSET_INDICATE = 0;
                    //$display("SSSSSHOLASSSS");
                    //$display(TX_O_SET);
                    case (TX_O_SET)
                        `OS_T: TX_CODE_GROUP = `K29p7_10bits;
                        `OS_V: TX_CODE_GROUP = `K30p7_10bits;
                        `OS_S: TX_CODE_GROUP = `K27p7_10bits;
                        `OS_R: TX_CODE_GROUP = `K23p7_10bits;
                        default: begin
                             $display("perdido");
                            $display(TX_O_SET);
                        end
                    endcase
                    TX_OSET_INDICATE = 1;
                    PUDR = 1;
                end             
                default: begin
                    nxt_state_cb = state_cb;

                end
            endcase
        end

        IDLE_I2B:begin
            TX_CODE_GROUP = `D16p2_10bits;
            TX_EVEN = 0;
            TX_OSET_INDICATE = 1;
            PUDR = 1;
            nxt_state_cb= GENERATE_CODE_GROUPS;            
        end
        default: nxt_state_cb= GENERATE_CODE_GROUPS;
    endcase

end


endmodule
