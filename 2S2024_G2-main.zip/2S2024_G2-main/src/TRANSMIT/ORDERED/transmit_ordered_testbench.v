`include "src/GLOBALS/globals.vh"
`include "src/TRANSMIT/ORDERED/transmit_ordered.v"
`include "src/TRANSMIT/ORDERED/transmit_ordered_tester.v"

module transmit_ordered_testbench();

wire GTX_CLK;
wire mr_main_reset;
wire TX_EN;
wire TX_ER;
wire TX_OSET_INDICATE;
wire TX_EVEN;
wire [2:0] xmit;
wire assert_ipidle;
wire [3:0] TX_O_SET;
wire [7:0] TXD;
wire transmiting;
wire receiving;

transmit_ordered DUT_TX_OR(
	.GTX_CLK(GTX_CLK),
	.mr_main_reset(mr_main_reset),
	.TX_EN(TX_EN),
	.TX_ER(TX_ER),
	.TX_OSET_INDICATE(TX_OSET_INDICATE),
	.TX_EVEN(TX_EVEN),
	.TXD(TXD),
	.xmit(xmit),
	.assert_ipidle(assert_ipidle),
	.TX_O_SET(TX_O_SET),
	.transmiting(transmiting),
	.receiving(receiving)
);


transmit_ordered_tester TEST_TX_OR(
	.GTX_CLK(GTX_CLK),
	.mr_main_reset(mr_main_reset),
	.TX_OSET_INDICATE(TX_OSET_INDICATE),
	.TX_EVEN(TX_EVEN),
	.TXD(TXD),
	.TX_O_SET(TX_O_SET),
	.TX_EN(TX_EN),
	.TX_ER(TX_ER)
	
);



initial begin
	$dumpfile("src/TRANSMIT/ORDERED/transmit_ordered.vcd");
	$dumpvars();	
	
end

endmodule

