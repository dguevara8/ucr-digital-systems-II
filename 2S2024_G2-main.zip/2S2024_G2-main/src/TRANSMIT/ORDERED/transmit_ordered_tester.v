`include "src/GLOBALS/globals.vh"
module transmit_ordered_tester (
    output reg GTX_CLK,
    output reg mr_main_reset,
    output reg TX_EN,
    output reg TX_ER,
    output reg TX_OSET_INDICATE,
    output reg TX_EVEN,
    output reg [2:0] xmit,
    output reg [7:0] TXD,
    output reg assert_ipidle,
    input [3:0] TX_O_SET,
    input transmiting,
    input receiving
    );
always begin
   #2 GTX_CLK = !GTX_CLK;
end

initial begin
    GTX_CLK = 0;
    mr_main_reset = 0;
    TX_EN = `FALSE;
    TX_ER = 0;
    TX_OSET_INDICATE = 1;
    TX_EVEN = 0;
    xmit = 0;
    TXD = 0;
	#4
    mr_main_reset = 1;
    #4
    TX_OSET_INDICATE = 1;
    TX_EN = `TRUE;
    TX_ER = `FALSE;
    #8
    //TX_OSET_INDICATE = 0;
    TX_ER = `FALSE;
    #4
    TX_EN = `FALSE;
    TX_OSET_INDICATE = 1;
    #8 

    
    
    //TX_OSET_INDICATE = 0;
    
    //Ya se reinicio la maquina



	#10 $finish;
end


endmodule
