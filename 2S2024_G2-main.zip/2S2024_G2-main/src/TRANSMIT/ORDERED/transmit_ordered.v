//Codigo de set ordenado 

`include "src/GLOBALS/globals.vh"
module transmit_ordered (
    input GTX_CLK,
    input mr_main_reset,
    input TX_EN,
    input TX_ER,
    input TX_OSET_INDICATE,
    input TX_EVEN,
    input [2:0] xmit, //Estado actual de la transmision
    input [7:0] TXD,
    input assert_ipidle,
    output reg [3:0] TX_O_SET,
    output reg transmiting,
    output reg receiving
    );


//Definicion de estados
localparam XMIT_DATA             = 3'b000;
localparam START_OF_PACKET       = 3'b001;
localparam TX_PACKET             = 3'b010;
localparam TX_DATA               = 3'b011;
localparam END_OF_PACKET_NOEXT   = 3'b100;
localparam EPD2_NOEXT            = 3'b101;
localparam EPD3                  = 3'b110;
localparam XMIT_IPIDLE           = 3'b110;

//Registros
reg [2:0] state_or, nxt_state_or;


//Logica secuencial
always @(posedge GTX_CLK) begin
    if (!mr_main_reset) begin
        state_or <= XMIT_DATA;
        TX_O_SET = `OS_I;
    end else begin
        state_or <= nxt_state_or;
    end
end

 // Logica combinacional para determinar el siguiente estado
    always @(*) begin
        // Valores por defecto
        nxt_state_or = state_or;
        //TX_O_SET = `OS_I;

        case (state_or)
            XMIT_DATA: begin
                TX_O_SET = `OS_I; // Valor por defecto en IDLE
                if (TX_EN && !TX_ER && TX_OSET_INDICATE) begin
                    nxt_state_or = START_OF_PACKET;
                end else if (assert_ipidle && TX_OSET_INDICATE) begin
                    nxt_state_or = XMIT_IPIDLE;
                end
            end

            START_OF_PACKET: begin
                transmiting = `TRUE;
                TX_O_SET = `OS_S ; // Indica /S/
                if (TX_OSET_INDICATE) nxt_state_or = TX_PACKET;
            end

            TX_PACKET: begin
                if (TX_EN == `TRUE) begin
                    //Void (/D/)
                    if (TX_EN == `FALSE && TX_ER == `TRUE && TXD != 8'b0000_1111) begin
                        TX_O_SET = `OS_V; // Transmite datos válidos
                    end else if (TX_EN == `TRUE && TX_ER == `TRUE) begin
                        TX_O_SET = `OS_V; // Transmite datos válidos
                    end else begin 
                        TX_O_SET = `OS_D;
                    end
                    //Para cambiar de estado cuando se envia el paquete
                    if (TX_OSET_INDICATE == `TRUE) begin
                        nxt_state_or = TX_PACKET;
                    end
                end else if (TX_EN == `FALSE && TX_ER == `FALSE) begin
                    nxt_state_or = END_OF_PACKET_NOEXT;
                end
            end
            /*
            TX_DATA: begin
                
            end */
            END_OF_PACKET_NOEXT: begin
                TX_O_SET = `OS_T; // Indica /T/
                if (TX_EVEN == `FALSE) begin
                    transmiting = `FALSE;
                end                 
                if (TX_OSET_INDICATE) nxt_state_or = EPD2_NOEXT;
            end

            EPD2_NOEXT: begin
                transmiting = `FALSE;
                TX_O_SET = `OS_R; // Indica /R/
                if (TX_OSET_INDICATE && TX_EVEN == `FALSE) begin
                    nxt_state_or = XMIT_DATA;
                end else if (TX_OSET_INDICATE && TX_EVEN == `TRUE) begin
                    nxt_state_or = EPD3;
                end
            end

            EPD3: begin
                TX_O_SET = `OS_R; // Indica /R/                
                if (TX_OSET_INDICATE) nxt_state_or = XMIT_DATA;
            end
            
            //XMIT_IPIDLE: begin
            //    TX_O_SET = `OS_R; // Indica /I/
            //    if (!assert_ipidle) begin
            //        nxt_state_or = XMIT_DATA;
            //    end
            //end

            default: begin
                nxt_state_or = XMIT_DATA;
            end
        endcase
    end

endmodule
